// === start sticky top === 
window.onscroll = function() {
    var navbar = document.querySelector('.navbar-initial');
    if (window.scrollY > 50) { // Adjust the scroll position as needed
        navbar.classList.add('sticky');
    } else {
        navbar.classList.remove('sticky');
    }
};

// === end sticky top === 







// === start swiper section 
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1, 
    spaceBetween: 30,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 3000, 
        disableOnInteraction: false,
    },
    breakpoints: {
        640: {
            slidesPerView: 1, 
            spaceBetween: 10,
        },
        768: {
            slidesPerView: 2, 
            spaceBetween: 20,
        },
        1024: {
            slidesPerView: 3, 
            spaceBetween: 30,
        },
    },
  });



//   start top scrool button 
// const scrollToTopBtn = document.getElementById("scrollToTopBtn");

// window.onscroll = function () {
//     if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
//         scrollToTopBtn.style.display = "block";
//     } else {
//         scrollToTopBtn.style.display = "none";
//     }
// };

// scrollToTopBtn.addEventListener("click", function () {
//     window.scrollTo({
//         top: 0,
//         behavior: "smooth" 
//     });
// });

//   end top scrool button 




AOS.init();